chrome.runtime.onMessage.addListener(onRuntimeMessage)

function onRuntimeMessage(message, sender, callback){

    if (message.action == "addJob"){
        server(false)
    } 

    return true

}