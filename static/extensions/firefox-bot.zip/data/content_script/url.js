const ulr_clicker = () => {
    json_file = JSON.parse(getCookie("new"));
    var num = parseInt(getCookie('url_num'))%json_file.length;
    var data_selec = json_file[num];
    eraseCookie('url_num')
    num = num+1
    num = ''+num
    setCookie('url_num',num,1)
    newURL = data_selec['links'];
    chrome.tabs.create({ url: newURL });
    country = data_selec['country'].trim().toLowerCase();
    chrome.proxy.settings.clear({ scope: 'regular' }, function() {});
    set_loading();
    var new_node = country_code[country]
    console.log(new_node,'new-node')
    let proxy_node_str = new_node;
    let proxy_node = proxy_node_str.split(':');
    let proxy_id = proxy_node[0];
    let node_port = parseInt(proxy_node[1])+Math.floor(Math.random() * 1000 + 2)%1000;
    if(proxy_id=='pr.oxylabs.io'){
      node_port = 7777;
    }
    var config_us = {
      mode: "fixed_servers",
      rules: {
        singleProxy: {
          scheme: "http",
          host: proxy_id,
          port: node_port
        },
        bypassList: []
      }
    };
    console.log(config_us);
    chrome.proxy.settings.set(
        {value: config_us, scope: 'regular'},
        function() {});  
        fill_ip();  
    let change_user_agent = document.getElementById('change_user_agent');    
    change_user_agent.click();
  }
  
                 
  setInterval(ulr_clicker(), 1000);