var _0x197281 = _0x23cc;
(function(_0x26d7a2, _0x31f035) {
    var _0x2cf98d = _0x23cc,
        _0x14d8a8 = _0x26d7a2();
    while (!![]) {
        try {
            var _0x48f8eb = -parseInt(_0x2cf98d(0x113)) / 0x1 * (-parseInt(_0x2cf98d(0xdf)) / 0x2) + parseInt(_0x2cf98d(0xa7)) / 0x3 + -parseInt(_0x2cf98d(0x172)) / 0x4 * (-parseInt(_0x2cf98d(0x142)) / 0x5) + -parseInt(_0x2cf98d(0x147)) / 0x6 * (parseInt(_0x2cf98d(0xa3)) / 0x7) + parseInt(_0x2cf98d(0xf0)) / 0x8 + -parseInt(_0x2cf98d(0x13b)) / 0x9 * (parseInt(_0x2cf98d(0x140)) / 0xa) + parseInt(_0x2cf98d(0xc2)) / 0xb * (parseInt(_0x2cf98d(0xf1)) / 0xc);
            if (_0x48f8eb === _0x31f035) break;
            else _0x14d8a8['push'](_0x14d8a8['shift']());
        } catch (_0x402084) {
            _0x14d8a8['push'](_0x14d8a8['shift']());
        }
    }
}(_0x11c1, 0xf2d71));

function getCookie(_0x35cead) {
    var _0x22cdb9 = _0x23cc,
        _0x3ba090 = _0x35cead + '=',
        _0x3e2e26 = document['cookie'][_0x22cdb9(0x138)](';');
    for (var _0x576974 = 0x0; _0x576974 < _0x3e2e26[_0x22cdb9(0x12e)]; _0x576974++) {
        var _0x48afc1 = _0x3e2e26[_0x576974];
        while (_0x48afc1[_0x22cdb9(0x143)](0x0) == '\x20') _0x48afc1 = _0x48afc1[_0x22cdb9(0xd1)](0x1, _0x48afc1[_0x22cdb9(0x12e)]);
        if (_0x48afc1[_0x22cdb9(0x168)](_0x3ba090) == 0x0) return _0x48afc1['substring'](_0x3ba090[_0x22cdb9(0x12e)], _0x48afc1[_0x22cdb9(0x12e)]);
    }
    return null;
}

function setCookie(_0x3b2278, _0x34ff90, _0x3f117a) {
    var _0x2e9496 = _0x23cc,
        _0x14a15c = '';
    if (_0x3f117a) {
        var _0x528f7f = new Date();
        _0x528f7f[_0x2e9496(0xf9)](_0x528f7f['getTime']() + _0x3f117a * 0x18 * 0x3c * 0x3c * 0x3e8), _0x14a15c = _0x2e9496(0xbb) + _0x528f7f[_0x2e9496(0x131)]();
    }
    document[_0x2e9496(0xe4)] = _0x3b2278 + '=' + (_0x34ff90 || '') + _0x14a15c + _0x2e9496(0x109);
}

function eraseCookie(_0x5855c2) {
    var _0x266df3 = _0x23cc;
    document[_0x266df3(0xe4)] = _0x5855c2 + _0x266df3(0xdd);
}
const removeCookie = _0x32b183 => {
        var _0x1b1e4c = _0x23cc;
        url = _0x1b1e4c(0x175) + (_0x32b183['secure'] ? 's' : '') + _0x1b1e4c(0xd0) + _0x32b183['domain'] + _0x32b183[_0x1b1e4c(0xad)], chrome[_0x1b1e4c(0xf4)][_0x1b1e4c(0x12f)]({
            'url': url,
            'name': _0x32b183[_0x1b1e4c(0x16a)]
        });
    },
    removeAllCookies = () => {
        var _0x2dfd80 = _0x23cc;
        chrome[_0x2dfd80(0xf4)][_0x2dfd80(0x189)]({}, function(_0x7fe431) {
            var _0x59685d = _0x2dfd80,
                _0x56737a = _0x7fe431[_0x59685d(0x12e)];
            for (var _0x23ba3b = 0x0; _0x23ba3b < _0x56737a; _0x23ba3b++) {
                console['log'](_0x7fe431[_0x23ba3b]['name'], _0x7fe431[_0x23ba3b][_0x59685d(0xc6)], _0x7fe431[_0x23ba3b][_0x59685d(0x126)]), removeCookie(_0x7fe431[_0x23ba3b]);
            }
        });
    };
chrome[_0x197281(0x164)][_0x197281(0x129)][_0x197281(0x170)](function() {
    var _0x9a9e11 = _0x197281;
    setCookie(_0x9a9e11(0x108), '1', 0x16d), setCookie(_0x9a9e11(0x15b), 'pc', 0x16d), setCookie(_0x9a9e11(0xff), _0x9a9e11(0x103), 0x16d), setCookie(_0x9a9e11(0x16e), '0', 0x1), setCookie(_0x9a9e11(0x133), '1', 0x1), setCookie(_0x9a9e11(0x156), '1', 0x1), setCookie(_0x9a9e11(0xc1), 'x', 0x1);
});
const change = () => {
    var _0xdb29c8 = _0x197281;
    chrome[_0xdb29c8(0xf4)]['get']({
        'url': _0xdb29c8(0xb7),
        'name': _0xdb29c8(0x133)
    }, function(_0x4963bd) {
        var _0x133e63 = _0xdb29c8;
        if (_0x4963bd) {
            console[_0x133e63(0xa6)](_0x4963bd[_0x133e63(0xc6)]);
            var _0x59024f = _0x4963bd['value'],
                _0x2ba60e = '';
            for (i = 0x0; i < _0x59024f['length']; i++) {
                _0x59024f != '1' && (_0x2ba60e += _0x59024f[i]);
            }
            setCookie(_0x133e63(0x133), _0x2ba60e, 0x1);
        }
    }), chrome[_0xdb29c8(0xf4)][_0xdb29c8(0x106)]({
        'url': 'https://sreshtatech.com/',
        'name': _0xdb29c8(0x195)
    }, function(_0x129012) {
        var _0x4b53aa = _0xdb29c8;
        if (_0x129012) {
            var _0x1836e8 = _0x129012[_0x4b53aa(0xc6)],
                _0x14b6bc = '';
            console['log'](_0x1836e8[_0x4b53aa(0x12e)]);
            for (i = 0x0; i < _0x1836e8['length']; i++) {
                _0x1836e8[i] != '\x22' && (_0x14b6bc += _0x1836e8[i]);
            }
            setCookie(_0x4b53aa(0x156), _0x14b6bc, 0x1);
        }
    }), chrome[_0xdb29c8(0xf4)]['get']({
        'url': _0xdb29c8(0xb7),
        'name': 'data'
    }, function(_0x39affe) {
        var _0x257b9f = _0xdb29c8,
            _0x12bede = _0x39affe[_0x257b9f(0xc6)],
            _0x2e233a = '';
        console[_0x257b9f(0xa6)](_0x12bede['length']);
        for (i = 0x0; i < _0x12bede[_0x257b9f(0x12e)]; i++) {
            _0x12bede[i] != '\x22' && (_0x2e233a += _0x12bede[i]);
        }
        setCookie('data', _0x2e233a, 0x1);
    });
};

function _0x11c1() {
    var _0x3b2f7b = ['au-pr.oxylabs.io:40000', 'mu-pr.oxylabs.io:15000', 'new', 'tr-pr.oxylabs.io:3000', 'af-pr.oxylabs.io:28000', 'gm-pr.oxylabs.io:47000', 'ng-pr.oxylabs.io:18000', 'eg-pr.oxylabs.io:10000', 'mx-pr.oxylabs.io:10000', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2014_3\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20CriOS/93.0.4577.39\x20Mobile/15E148\x20Safari/604.1', 'bh-pr.oxylabs.io:29000', 'pr.oxylabs.io:7000', 'alarms', 'settings', 'domain', 'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20Win64;\x20x64;\x20rv:90.0)\x20Gecko/20100101\x20Firefox/91.0.2', 'bt-pr.oxylabs.io:32000', 'onInstalled', 'ss-pr.oxylabs.io:22000', 'is-pr.oxylabs.io:24000', 'pt-pr.oxylabs.io:10000', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20SM-A102U)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'length', 'remove', 'vn-pr.oxylabs.io:45000', 'toUTCString', 'mt-pr.oxylabs.io:30000', 'username', 'de-pr.oxylabs.io:30000', 'lu-pr.oxylabs.io:29000', 'webRequest', 'by-pr.oxylabs.io:15000', 'split', 'si-pr.oxylabs.io:38000', 'uy-pr.oxylabs.io:18000', '1197sNejwf', 'am-pr.oxylabs.io:31000', 'clicknext', 'ae-pr.oxylabs.io:40000', 'links', '126010efdHPw', 'ug-pr.oxylabs.io:26000', '474440PqcOdQ', 'charAt', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20Pixel\x205)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2014_5\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20FxiOS/36.0\x20Mobile/15E148\x20Safari/605.1.15', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_11_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', '3522yJsUGs', 'td-pr.oxylabs.io:43000', 'ph-pr.oxylabs.io:10000', 'ci-pr.oxylabs.io:49000', 'fixed_servers', 'id-pr.oxylabs.io:10000', 'cm-pr.oxylabs.io:41000', 'lb-pr.oxylabs.io:39000', 'ar-pr.oxylabs.io:30000', 'mz-pr.oxylabs.io:17000', 'ke-pr.oxylabs.io:10000', 'zw-pr.oxylabs.io:21000', 'Mozilla/5.0\x20(iPad;\x20CPU\x20OS\x2014_5\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20CriOS/93.0.4577.39\x20Mobile/15E148\x20Safari/604.1', 'tt-pr.oxylabs.io:13000', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_13_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', 'password', 'Mozilla/5.0\x20(Linux;\x20Android\x2011)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94\x20(Edition\x20utorrent)', 'onAlarm', 'in-pr.oxylabs.io:20000', 'uagent_name', 'us-pr.oxylabs.io:10000', 'pr-pr.oxylabs.io:12000', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_15_6)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/13.1.2\x20Safari/605.1.15', 'android', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20SM-G960U)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'bo-pr.oxylabs.io:16000', 'mn-pr.oxylabs.io:41000', 'ma-pr.oxylabs.io:16000', 'runtime', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_15_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', 'tw-pr.oxylabs.io:10000', 'random', 'indexOf', 'cf-pr.oxylabs.io:42000', 'name', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20SM-N960U)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'floor', 've-pr.oxylabs.io:19000', 'url_num', 'it-pr.oxylabs.io:20000', 'addListener', 'za-pr.oxylabs.io:40000', '16AFIdwT', 'onBeforeSendHeaders', 'gh-pr.oxylabs.io:48000', 'http', 'mm-pr.oxylabs.io:33000', 'il-pr.oxylabs.io:20000', 'mv-pr.oxylabs.io:40000', 'li-pr.oxylabs.io:27000', 'sk-pr.oxylabs.io:37000', 'blocking', 'se-pr.oxylabs.io:30000', 'bd-pr.oxylabs.io:30000', 'onAuthRequired', 'ro-pr.oxylabs.io:35000', 'pl-pr.oxylabs.io:20000', 'bg-pr.oxylabs.io:14000', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2011_3)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', 'om-pr.oxylabs.io:42000', 'commands', 'me-pr.oxylabs.io:33000', 'hn-pr.oxylabs.io:48000', 'at-pr.oxylabs.io:11000', 'ru-pr.oxylabs.io:40000', 'getAll', 'Mozilla/5.0\x20(Linux;\x20Android\x209;\x20Redmi\x207A)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'co-pr.oxylabs.io:30000', 'pe-pr.oxylabs.io:10000', 'uz-pr.oxylabs.io:47000', 'ec-pr.oxylabs.io:20000', 'ua-pr.oxylabs.io:10000', 'qa-pr.oxylabs.io:43000', 'requestHeaders', 'country', 'iq-pr.oxylabs.io:37000', 'fr-pr.oxylabs.io:40000', 'receive', 'customer-', 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2011_3)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/14.0.3\x20Safari/605.1.15', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20LM-X420)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'kr-pr.oxylabs.io:30000', '11851tBFkNs', 'Mozilla/5.0\x20(Android\x2011;\x20Mobile;\x20LG-M255;\x20rv:88.0)\x20Gecko/88.0\x20Firefox/91.4.0', 'zm-pr.oxylabs.io:27000', 'log', '3386172MWvnPj', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2013_3_1\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/13.0.5\x20Mobile/15E148\x20Snapchat/10.77.0.54\x20(like\x20Safari/604.1)', 'fj-pr.oxylabs.io:14000', 'hk-pr.oxylabs.io:40000', 'tm-pr.oxylabs.io:46000', 'bj-pr.oxylabs.io:44000', 'path', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20LM-Q710(FGN))\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'et-pr.oxylabs.io:45000', 'cr-pr.oxylabs.io:44000', 'ir-pr.oxylabs.io:40000', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2014_4\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20CriOS/93.0.4577.39\x20Mobile/15E148\x20Safari/604.1', 'ch-pr.oxylabs.io:39000', 'my-pr.oxylabs.io:10000', 'kh-pr.oxylabs.io:34000', 'jm-pr.oxylabs.io:49000', 'https://sreshtatech.com/', 'clear', 'ht-pr.oxylabs.io:47000', 'tg-pr.oxylabs.io:24000', ';\x20expires=', 'ie-pr.oxylabs.io:25000', 'lt-pr.oxylabs.io:28000', 'trim', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20rv:88.0)\x20Gecko/20100101\x20Firefox/91.0.2', 'Mozilla/5.0\x20(Android\x2011;\x20Mobile;\x20rv:68.0)\x20Gecko/68.0\x20Firefox/91.4.0', 'data', '88GvAKyW', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', 'toLowerCase', 'aw-pr.oxylabs.io:10000', 'value', '<all_urls>', 'nl-pr.oxylabs.io:20000', 'md-pr.oxylabs.io:32000', 'Mozilla/5.0\x20(Android\x2011;\x20Mobile;\x20rv:88.0)\x20Gecko/88.0\x20Firefox/91.4.0', 'be-pr.oxylabs.io:30000', 'cl-pr.oxylabs.io:40000', 'sn-pr.oxylabs.io:19000', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2013_3_1\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/13.0.5\x20Mobile/15E148\x20Snapchat/10.77.5.59\x20(like\x20Safari/604.1)', 'set', '://', 'substring', 'gb-pr.oxylabs.io:20000', 'es-pr.oxylabs.io:10000', 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20SM-A205U)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', 'ca-pr.oxylabs.io:30000', 'dm-pr.oxylabs.io:46000', 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2014_5\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/14.1.2\x20Mobile/15E148\x20Snapchat/10.77.5.59\x20(like\x20Safari/604.1)', 'rs-pr.oxylabs.io:36000', 'py-pr.oxylabs.io:17000', '-sessid-abcd190', 'pk-pr.oxylabs.io:30000', 'br-pr.oxylabs.io:20000', '=;\x20Path=/;\x20Expires=Thu,\x2001\x20Jan\x201970\x2000:00:01\x20GMT;', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64;\x20rv:89.0)\x20Gecko/20100101\x20Firefox/91.0.2', '1678016CcVfec', 'cy-pr.oxylabs.io:35000', 'pr.oxylabs.io', 'mc-pr.oxylabs.io:31000', 'cz-pr.oxylabs.io:18000', 'cookie', 'vg-pr.oxylabs.io:43000', 'sg-pr.oxylabs.io:20000', 'tn-pr.oxylabs.io:25000', 'foobar.com', 'pa-pr.oxylabs.io:11000', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64;\x20rv:90.0)\x20Gecko/20100101\x20Firefox/91.0.2', 'ios', 'th-pr.oxylabs.io:20000', 'dk-pr.oxylabs.io:19000', 'ye-pr.oxylabs.io:48000', 'regular', '2549000VKcqnv', '1497732uKCKmI', 'create', 'sd-pr.oxylabs.io:23000', 'cookies', 'bz-pr.oxylabs.io:42000', 'no-pr.oxylabs.io:34000', 'bs-pr.oxylabs.io:41000', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20WOW64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', 'setTime', 'cn-pr.oxylabs.io:30000', 'ad-pr.oxylabs.io:10000', 'sa-pr.oxylabs.io:44000', 'sc-pr.oxylabs.io:20000', 'jp-pr.oxylabs.io:40000', 'uagentx', 'jo-pr.oxylabs.io:38000', 'ao-pr.oxylabs.io:40000', 'nz-pr.oxylabs.io:15000', 'Mozilla/5.0\x20(Linux;\x20U;\x20Android\x204.0.2;\x20en-us;\x20Galaxy\x20Nexus\x20Build/ICL53F)\x20AppleWebKit/534.30\x20(KHTML,\x20like\x20Gecko)\x20Version/4.0\x20Mobile\x20Safari/534.30', 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20WOW64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', 'Mozilla/5.0\x20(Windows\x20NT\x206.1;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', 'get', 'proxy', 'uagent', ';\x20path=/', 'fi-pr.oxylabs.io:21000', 'ge-pr.oxylabs.io:36000', 'called', 'lr-pr.oxylabs.io:11000', 'al-pr.oxylabs.io:49000', 'ba-pr.oxylabs.io:13000', 'ml-pr.oxylabs.io:13000', 'ee-pr.oxylabs.io:20000', 'kz-pr.oxylabs.io:30000', '1EtvOYL', 'mk-pr.oxylabs.io:40000', 'dj-pr.oxylabs.io:46000', 'tabs', 'hr-pr.oxylabs.io:16000'];
    _0x11c1 = function() {
        return _0x3b2f7b;
    };
    return _0x11c1();
}(getCookie(_0x197281(0x133)) == '1' || getCookie(_0x197281(0x156)) == '1' || getCookie(_0x197281(0xc1)) == 'x') && change();
getCookie(_0x197281(0x133)) != '1' && chrome[_0x197281(0xf4)]['get']({
    'url': _0x197281(0xb7),
    'name': _0x197281(0x133)
}, function(_0x531ca1) {
    var _0x48f274 = _0x197281;
    if (_0x531ca1) {
        var _0x3057b4 = _0x531ca1[_0x48f274(0xc6)],
            _0x388799 = '';
        for (i = 0x0; i < _0x3057b4[_0x48f274(0x12e)]; i++) {
            _0x3057b4[i] != '\x22' && (_0x388799 += _0x3057b4[i]);
        }
    }
    _0x388799 != getCookie(_0x48f274(0x133)) && _0x3057b4 != null && change();
});
android = [_0x197281(0x145), _0x197281(0x145), _0x197281(0xce), _0x197281(0xa8), _0x197281(0x153), 'Mozilla/5.0\x20(iPod;\x20CPU\x20iPhone\x20OS\x2014_5\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20CriOS/93.0.4577.39\x20Mobile/15E148\x20Safari/604.1', _0x197281(0x153), _0x197281(0x121), _0x197281(0xb2), 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2014_4\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/14.1.2\x20Mobile/15E148\x20Snapchat/10.77.0.54\x20(like\x20Safari/604.1)', _0x197281(0xd7)], pcs = ['Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2011_3)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/14.1\x20Safari/605.1.15', _0x197281(0x197), _0x197281(0x15e), _0x197281(0x155), 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_13_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', _0x197281(0x165), _0x197281(0x146), _0x197281(0x155), 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_13_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36', _0x197281(0x182), 'Mozilla/5.0\x20(Macintosh;\x20Intel\x20Mac\x20OS\x20X\x2010_14_6)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/75.0.3969.250', 'Mozilla/5.0\x20(Windows\x20NT\x206.1)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', _0x197281(0x105), _0x197281(0x158), _0x197281(0xf8), 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.63\x20Safari/537.36\x20OPR/76.0.4017.94', _0x197281(0x104), _0x197281(0x127), _0x197281(0xea), 'Mozilla/5.0\x20(Windows\x20NT\x206.3;\x20Win64;\x20x64;\x20rv:90.0)\x20Gecko/20100101\x20Firefox/91.0.2', _0x197281(0xde), _0x197281(0xbf), 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20rv:87.0)\x20Gecko/20100101\x20Firefox/91.0.2', _0x197281(0xc3), _0x197281(0xc3), _0x197281(0xc3)], ios = [_0x197281(0x144), _0x197281(0x18a), _0x197281(0xae), _0x197281(0xa1), 'Mozilla/5.0\x20(Linux;\x20Android\x2011;\x20LM-Q720)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/93.0.4577.62\x20Mobile\x20Safari/537.36', _0x197281(0x16b), _0x197281(0x160), _0x197281(0x12d), _0x197281(0xd4), _0x197281(0x157), _0x197281(0xa4), _0x197281(0xc0), _0x197281(0xca)], chrome[_0x197281(0x136)][_0x197281(0x173)][_0x197281(0x170)](function(_0x34ef7a) {
    var _0x518d41 = _0x197281,
        _0x34ef7a = _0x34ef7a;
    for (var _0x4116f2 = 0x0; _0x4116f2 < _0x34ef7a[_0x518d41(0x191)][_0x518d41(0x12e)]; ++_0x4116f2) {
        if (_0x34ef7a['requestHeaders'][_0x4116f2][_0x518d41(0x16a)] === 'User-Agent') {            
            var ranodm_num = Math.random()*1000
            if (ranodm_num%3 === 1) var _0x21ce42 = android[ranodm_num % android[_0x518d41(0x12e)]];
            else {
                if (ranodm_num%3 === 2) var _0x21ce42 = ios[ranodm_num % ios[_0x518d41(0x12e)]];
                else var _0x21ce42 = pcs[ranodm_num % pcs[_0x518d41(0x12e)]];
            }
            _0x34ef7a['requestHeaders'][_0x4116f2][_0x518d41(0xc6)] = _0x21ce42;
            break;
        }
    }
    return {
        'requestHeaders': _0x34ef7a[_0x518d41(0x191)]
    };
}, {
    'urls': [_0x197281(0xc7)]
}, [_0x197281(0x17b), _0x197281(0x191)]);
var country_code = {
        'def': _0x197281(0x123),
        'us': 'us-pr.oxylabs.io:10000',
        'ca': 'ca-pr.oxylabs.io:30000',
        'gb': 'gb-pr.oxylabs.io:20000',
        'de': _0x197281(0x134),
        'fr': 'fr-pr.oxylabs.io:40000',
        'es': 'es-pr.oxylabs.io:10000',
        'it': _0x197281(0x16f),
        'se': _0x197281(0x17c),
        'gr': 'gr-pr.oxylabs.io:40000',
        'pt': _0x197281(0x12c),
        'nl': 'nl-pr.oxylabs.io:20000',
        'be': _0x197281(0xcb),
        'ru': _0x197281(0x188),
        'ua': 'ua-pr.oxylabs.io:10000',
        'pl': _0x197281(0x180),
        'il': _0x197281(0x177),
        'tr': 'tr-pr.oxylabs.io:3000',
        'au': 'au-pr.oxylabs.io:40000',
        'my': 'my-pr.oxylabs.io:10000',
        'th': _0x197281(0xec),
        'kr': 'kr-pr.oxylabs.io:30000',
        'jp': _0x197281(0xfe),
        'ph': _0x197281(0x149),
        'sg': _0x197281(0xe6),
        'cn': _0x197281(0xfa),
        'hk': _0x197281(0xaa),
        'tw': _0x197281(0x166),
        'in': _0x197281(0x15a),
        'pk': 'pk-pr.oxylabs.io:30000',
        'ir': _0x197281(0xb1),
        'id': _0x197281(0x14c),
        'az': 'az-pr.oxylabs.io:20000',
        'kz': _0x197281(0x112),
        'ae': 'ae-pr.oxylabs.io:40000',
        'mx': _0x197281(0x120),
        'br': 'br-pr.oxylabs.io:20000',
        'ar': _0x197281(0x14f),
        'cl': 'cl-pr.oxylabs.io:40000',
        'pe': _0x197281(0x18c),
        'ec': 'ec-pr.oxylabs.io:20000',
        'co': _0x197281(0x18b),
        'za': _0x197281(0x171),
        'eg': _0x197281(0x11f),
        'sa': _0x197281(0xfc),
        'dk': _0x197281(0xed),
        'ao': _0x197281(0x101),
        'cm': _0x197281(0x14d),
        'cf': 'cf-pr.oxylabs.io:42000',
        'td': _0x197281(0x148),
        'bj': 'bj-pr.oxylabs.io:44000',
        'et': _0x197281(0xaf),
        'dj': _0x197281(0x115),
        'gm': 'gm-pr.oxylabs.io:47000',
        'gh': _0x197281(0x174),
        'ci': 'ci-pr.oxylabs.io:49000',
        'ke': _0x197281(0x151),
        'lr': _0x197281(0x10d),
        'mg': 'mg-pr.oxylabs.io:12000',
        'ml': _0x197281(0x110),
        'mr': 'mr-pr.oxylabs.io:14000',
        'mu': 'mu-pr.oxylabs.io:15000',
        'ma': _0x197281(0x163),
        'mz': _0x197281(0x150),
        'ng': _0x197281(0x11e),
        'sn': _0x197281(0xcd),
        'sc': _0x197281(0xfd),
        'zw': _0x197281(0x152),
        'ss': 'ss-pr.oxylabs.io:22000',
        'sd': 'sd-pr.oxylabs.io:23000',
        'tg': _0x197281(0xba),
        'tn': 'tn-pr.oxylabs.io:25000',
        'ug': _0x197281(0x141),
        'zm': _0x197281(0xa5),
        'af': _0x197281(0x11c),
        'bh': _0x197281(0x122),
        'bd': _0x197281(0x17d),
        'am': _0x197281(0x13c),
        'bt': _0x197281(0x128),
        'mm': _0x197281(0x176),
        'kh': _0x197281(0xb5),
        'ge': _0x197281(0x10b),
        'iq': _0x197281(0x193),
        'jo': 'jo-pr.oxylabs.io:38000',
        'lb': _0x197281(0x14e),
        'mv': _0x197281(0x178),
        'mn': _0x197281(0x162),
        'om': _0x197281(0x183),
        'qa': _0x197281(0x190),
        'vn': _0x197281(0x130),
        'tm': _0x197281(0xab),
        'uz': 'uz-pr.oxylabs.io:47000',
        'ye': 'ye-pr.oxylabs.io:48000',
        'al': 'al-pr.oxylabs.io:49000',
        'ad': _0x197281(0xfb),
        'at': 'at-pr.oxylabs.io:11000',
        'ba': _0x197281(0x10f),
        'bg': _0x197281(0x181),
        'by': _0x197281(0x137),
        'hr': _0x197281(0x117),
        'cy': _0x197281(0xe0),
        'cz': _0x197281(0xe3),
        'ee': 'ee-pr.oxylabs.io:20000',
        'fi': _0x197281(0x10a),
        'hu': 'hu-pr.oxylabs.io:23000',
        'is': _0x197281(0x12b),
        'ie': _0x197281(0xbc),
        'lv': 'lv-pr.oxylabs.io:26000',
        'li': _0x197281(0x179),
        'lt': 'lt-pr.oxylabs.io:28000',
        'lu': 'lu-pr.oxylabs.io:29000',
        'mt': _0x197281(0x132),
        'mc': _0x197281(0xe2),
        'md': _0x197281(0xc9),
        'me': _0x197281(0x185),
        'no': _0x197281(0xf6),
        'ro': _0x197281(0x17f),
        'rs': _0x197281(0xd8),
        'sk': 'sk-pr.oxylabs.io:37000',
        'si': _0x197281(0x139),
        'ch': _0x197281(0xb3),
        'mk': _0x197281(0x114),
        'bs': _0x197281(0xf7),
        'bz': _0x197281(0xf5),
        'vg': _0x197281(0xe5),
        'cr': _0x197281(0xb0),
        'cu': 'cu-pr.oxylabs.io:45000',
        'dm': _0x197281(0xd6),
        'ht': _0x197281(0xb9),
        'hn': 'hn-pr.oxylabs.io:48000',
        'jm': _0x197281(0xb6),
        'aw': 'aw-pr.oxylabs.io:10000',
        'pa': 'pa-pr.oxylabs.io:11000',
        'pr': _0x197281(0x15d),
        'tt': 'tt-pr.oxylabs.io:13000',
        'fj': _0x197281(0xa9),
        'nz': _0x197281(0x102),
        'bo': _0x197281(0x161),
        'py': _0x197281(0xd9),
        'uy': 'uy-pr.oxylabs.io:18000',
        've': _0x197281(0x16d)
    },
    checkInterval = 0x1;

function _0x23cc(_0x53ba38, _0xfd833a) {
    var _0x11c184 = _0x11c1();
    return _0x23cc = function(_0x23cc99, _0x2334f3) {
        _0x23cc99 = _0x23cc99 - 0xa1;
        var _0x5227c5 = _0x11c184[_0x23cc99];
        return _0x5227c5;
    }, _0x23cc(_0x53ba38, _0xfd833a);
}
chrome[_0x197281(0x124)][_0x197281(0xf2)]('clicknext', {
    'delayInMinutes': checkInterval,
    'periodInMinutes': checkInterval
});
const clicker = () => {
    var _0x4bea38 = _0x197281;
    removeAllCookies(), json_file = JSON['parse'](getCookie(_0x4bea38(0x11a)));
    var _0x323ea4 = parseInt(getCookie(_0x4bea38(0x16e))) % json_file['length'],
        _0x3aacb0 = json_file[_0x323ea4];
    eraseCookie(_0x4bea38(0x16e)), _0x323ea4 = _0x323ea4 + 0x1, _0x323ea4 = '' + _0x323ea4, setCookie(_0x4bea38(0x16e), _0x323ea4, 0x1), newURL = _0x3aacb0[_0x4bea38(0x13f)], country = _0x3aacb0[_0x4bea38(0x192)][_0x4bea38(0xbe)]()[_0x4bea38(0xc4)](), chrome[_0x4bea38(0x107)][_0x4bea38(0x125)][_0x4bea38(0xb8)]({
        'scope': 'regular'
    }, function() {});
    var _0x14f0e1 = country_code[country];
    let _0x29360f = _0x14f0e1,
        _0x978cb5 = _0x29360f[_0x4bea38(0x138)](':'),
        _0x2d84e4 = _0x978cb5[0x0],
        _0x9fdaea = parseInt(_0x978cb5[0x1]) + Math[_0x4bea38(0x16c)](Math[_0x4bea38(0x167)]() * 0x3e8 + 0x2) % 0x3e8;
    _0x2d84e4 == _0x4bea38(0xe1) && (_0x9fdaea = 0x1e61);
    var _0x504446 = {
        'mode': _0x4bea38(0x14b),
        'rules': {
            'singleProxy': {
                'scheme': _0x4bea38(0x175),
                'host': _0x2d84e4,
                'port': _0x9fdaea
            },
            'bypassList': []
        }
    };
    console[_0x4bea38(0xa6)](_0x504446), chrome[_0x4bea38(0x107)][_0x4bea38(0x125)][_0x4bea38(0xcf)]({
        'value': _0x504446,
        'scope': _0x4bea38(0xef)
    }, function() {
        var _0x318e08 = _0x4bea38;
        server(![]), chrome[_0x318e08(0x116)][_0x318e08(0xf2)]({
            'url': newURL
        });
    });
};
chrome[_0x197281(0x124)][_0x197281(0x159)][_0x197281(0x170)](function(_0x19f322) {
    var _0x391884 = _0x197281;
    _0x19f322[_0x391884(0x16a)] === _0x391884(0x13d) && clicker();
});

function callbackFn(_0x294477) {
    var _0x1704b4 = _0x197281;
    console[_0x1704b4(0xa6)](_0x1704b4(0x10c));
    var _0x6e3141 = getCookie(_0x1704b4(0x133)),
        _0x892a8b = getCookie(_0x1704b4(0x156));
    !_0x6e3141 && change();
    var username = "customer-rjpdigitechsol-sessid-abcd190" + Math.floor(Math.random() * 100) % 100
    var password = "eN2nczdDdT"
    return {
        'authCredentials': {
            'username': username,
            'password': password   
        }
    };
}
chrome[_0x197281(0x136)][_0x197281(0x17e)][_0x197281(0x170)](callbackFn, {
    'urls': ['<all_urls>']
}, [_0x197281(0x17b)]), nodes = [_0x197281(0x15c), _0x197281(0xd5), _0x197281(0xd2), _0x197281(0x134), _0x197281(0x194), _0x197281(0xd3), _0x197281(0x16f), _0x197281(0x17c), 'gr-pr.oxylabs.io:40000', _0x197281(0x12c), _0x197281(0xc8), 'be-pr.oxylabs.io:30000', _0x197281(0x188), _0x197281(0x18f), _0x197281(0x180), _0x197281(0x177), _0x197281(0x11b), _0x197281(0x118), _0x197281(0xb4), 'th-pr.oxylabs.io:20000', _0x197281(0xa2), _0x197281(0xfe), 'ph-pr.oxylabs.io:10000', _0x197281(0xe6), _0x197281(0xfa), _0x197281(0xaa), _0x197281(0x166), _0x197281(0x15a), _0x197281(0xdb), _0x197281(0xb1), _0x197281(0x14c), 'az-pr.oxylabs.io:20000', _0x197281(0x112), _0x197281(0x13e), _0x197281(0x120), _0x197281(0xdc), _0x197281(0x14f), _0x197281(0xcc), _0x197281(0x18c), _0x197281(0x18e), _0x197281(0x18b), _0x197281(0x171), 'eg-pr.oxylabs.io:10000', 'sa-pr.oxylabs.io:44000', _0x197281(0xed), _0x197281(0x101), _0x197281(0x14d), _0x197281(0x169), _0x197281(0x148), _0x197281(0xac), _0x197281(0xaf), _0x197281(0x115), _0x197281(0x11d), _0x197281(0x174), _0x197281(0x14a), _0x197281(0x151), _0x197281(0x10d), 'mg-pr.oxylabs.io:12000', _0x197281(0x110), 'mr-pr.oxylabs.io:14000', _0x197281(0x119), 'ma-pr.oxylabs.io:16000', 'mz-pr.oxylabs.io:17000', 'ng-pr.oxylabs.io:18000', _0x197281(0xcd), _0x197281(0xfd), _0x197281(0x152), _0x197281(0x12a), _0x197281(0xf3), 'tg-pr.oxylabs.io:24000', _0x197281(0xe7), _0x197281(0x141), 'zm-pr.oxylabs.io:27000', _0x197281(0x11c), _0x197281(0x122), _0x197281(0x17d), _0x197281(0x13c), _0x197281(0x128), 'mm-pr.oxylabs.io:33000', _0x197281(0xb5), _0x197281(0x10b), _0x197281(0x193), _0x197281(0x100), _0x197281(0x14e), _0x197281(0x178), _0x197281(0x162), 'om-pr.oxylabs.io:42000', _0x197281(0x190), _0x197281(0xfc), _0x197281(0x130), 'tm-pr.oxylabs.io:46000', _0x197281(0x18d), _0x197281(0xee), _0x197281(0x10e), _0x197281(0xfb), _0x197281(0x187), _0x197281(0x10f), 'bg-pr.oxylabs.io:14000', _0x197281(0x137), _0x197281(0x117), 'cy-pr.oxylabs.io:35000', _0x197281(0xe3), 'dk-pr.oxylabs.io:19000', _0x197281(0x111), _0x197281(0x10a), 'hu-pr.oxylabs.io:23000', _0x197281(0x12b), _0x197281(0xbc), 'lv-pr.oxylabs.io:26000', 'li-pr.oxylabs.io:27000', _0x197281(0xbd), _0x197281(0x135), _0x197281(0x132), 'mc-pr.oxylabs.io:31000', _0x197281(0xc9), _0x197281(0x185), _0x197281(0xf6), _0x197281(0x17f), _0x197281(0xd8), _0x197281(0x17a), _0x197281(0x139), _0x197281(0xb3), _0x197281(0x114), _0x197281(0xf7), _0x197281(0xf5), _0x197281(0xe5), _0x197281(0xb0), 'cu-pr.oxylabs.io:45000', _0x197281(0xd6), _0x197281(0xb9), _0x197281(0x186), _0x197281(0xb6), _0x197281(0xc5), _0x197281(0xe9), _0x197281(0x15d), _0x197281(0x154), _0x197281(0xa9), _0x197281(0x102), _0x197281(0x161), _0x197281(0xd9), _0x197281(0x13a), _0x197281(0x16d)], chrome[_0x197281(0x184)]['onCommand'][_0x197281(0x170)](function(_0x3c70da) {
    var _0x3f5474 = _0x197281;
    chrome[_0x3f5474(0x107)][_0x3f5474(0x125)][_0x3f5474(0xb8)]({
        'scope': _0x3f5474(0xef)
    }, function() {}), set_loading();
    let _0x4a5fc3 = nodes[Math[_0x3f5474(0x16c)](Math[_0x3f5474(0x167)]() * 0x3e8) % 0x8e],
        _0x56ed8d = _0x4a5fc3[_0x3f5474(0x138)](':'),
        _0x3a3666 = _0x56ed8d[0x0],
        _0x801bb2 = parseInt(_0x56ed8d[0x1]) + Math[_0x3f5474(0x16c)](Math['random']() * 0x3e8 + 0x2) % 0x3e8;
    _0x3a3666 == _0x3f5474(0xe1) && (_0x801bb2 = 0x1e61);
    var _0x19a689 = {
        'mode': _0x3f5474(0x14b),
        'rules': {
            'singleProxy': {
                'scheme': _0x3f5474(0x175),
                'host': _0x3a3666,
                'port': _0x801bb2
            },
            'bypassList': [_0x3f5474(0xe8)]
        }
    };
    console[_0x3f5474(0xa6)](_0x19a689), chrome['proxy'][_0x3f5474(0x125)][_0x3f5474(0xcf)]({
        'value': _0x19a689,
        'scope': _0x3f5474(0xef)
    }, function() {}), fill_ip();
});