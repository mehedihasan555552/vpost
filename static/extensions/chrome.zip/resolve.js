/* globals moment, offsets */
'use strict';

var resolve = {};

resolve.remote = () => fetch('https://api.freegeoip.app/json/?apikey=e89cc8e0-7842-11ec-93c4-b18c575128f2').then(r => r.json()).then(j => {
  if (j && j.time_zone) {
    return j.time_zone;
  }
  else {
    throw Error('Something went wrong!');
  }
});

resolve.analyze = timezone => {
  const m = moment.tz(Date.now(), timezone);
  const country = timezone.split('/')[1].replace(/[-_]/g, ' ');
  const storage = offsets[timezone];
  storage.msg = storage.msg || {
    'standard': country + ' Standard Time',
    'daylight': country + ' Daylight Time'
  };
  return {
    offset: m.utcOffset(),
    storage
  };
};
